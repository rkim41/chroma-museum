import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import * as MediaLibrary from 'expo-media-library';
import React, { useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  Image,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { FILTERS } from '../utils/colorFilter';

const { width: W } = Dimensions.get('window');

export default function HomeScreen() {
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [mediaPermission, requestMediaPermission] = MediaLibrary.usePermissions();
  const [capturedUri, setCapturedUri] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState('deuteranopia');
  const [strength, setStrength] = useState(0.9);
  const [isCapturing, setIsCapturing] = useState(false);
  const cameraRef = useRef<CameraView>(null);

  if (!cameraPermission) return <View style={s.centered} />;

  if (!cameraPermission.granted) {
    return (
      <View style={s.centered}>
        <Text style={s.permTitle}>Camera Permission Required</Text>
        <Text style={s.permDesc}>Chroma needs camera access to scan artwork in the museum.</Text>
        <TouchableOpacity style={s.btn} onPress={requestCameraPermission}>
          <Text style={s.btnText}>Allow Camera</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleCapture = async () => {
    if (!cameraRef.current || isCapturing) return;
    setIsCapturing(true);
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.9 });
      if (photo) setCapturedUri(photo.uri);
    } catch {
      Alert.alert('Error', 'Could not capture photo. Please try again.');
    } finally {
      setIsCapturing(false);
    }
  };

  const handleSave = async () => {
    if (!capturedUri) return;
    if (!mediaPermission?.granted) await requestMediaPermission();
    try {
      await MediaLibrary.saveToLibraryAsync(capturedUri);
      Alert.alert('Saved', 'Image saved to your photo library.');
    } catch {
      Alert.alert('Error', 'Could not save image.');
    }
  };

  const handleRescan = () => setCapturedUri(null);

  if (capturedUri) {
    const filter = FILTERS.find(f => f.id === selectedFilter);
    return (
      <View style={s.root}>
        <StatusBar barStyle="light-content" />
        <View style={s.header}>
          <Text style={s.headerTitle}>CHROMA</Text>
          <Text style={s.headerSub}>Color Vision Aid</Text>
        </View>
        <Image source={{ uri: capturedUri }} style={s.resultImage} resizeMode="contain" />
        <View style={s.filterBadge}>
          <View style={s.filterDot} />
          <Text style={s.filterBadgeText}>{filter?.label} · {Math.round(strength * 100)}% strength</Text>
        </View>
        <Text style={s.filterDesc}>{filter?.description}</Text>
        <View style={s.resultActions}>
          <TouchableOpacity style={[s.btn, s.btnOutline]} onPress={handleRescan}>
            <Text style={[s.btnText, s.btnTextDark]}>Scan Again</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.btn} onPress={handleSave}>
            <Text style={s.btnText}>Save Image</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={s.root}>
      <StatusBar barStyle="light-content" />
      <View style={s.header}>
        <Text style={s.headerTitle}>CHROMA</Text>
        <Text style={s.headerSub}>Museum Color Aid</Text>
      </View>
      <View style={s.cameraWrap}>
        <CameraView ref={cameraRef} style={s.camera} facing="back">
          <View style={s.corners}>
            <View style={[s.corner, s.cornerTL]} />
            <View style={[s.corner, s.cornerTR]} />
            <View style={[s.corner, s.cornerBL]} />
            <View style={[s.corner, s.cornerBR]} />
          </View>
          <View style={s.activeBadge}>
            <View style={s.activeDot} />
            <Text style={s.activeBadgeText}>{FILTERS.find(f => f.id === selectedFilter)?.label} active</Text>
          </View>
        </CameraView>
      </View>
      <ScrollView style={s.controls} contentContainerStyle={s.controlsInner}>
        <Text style={s.sectionLabel}>VISION FILTER</Text>
        <View style={s.filterRow}>
          {FILTERS.map(f => (
            <TouchableOpacity key={f.id} style={[s.filterPill, selectedFilter === f.id && s.filterPillActive]} onPress={() => setSelectedFilter(f.id)}>
              <Text style={[s.filterPillText, selectedFilter === f.id && s.filterPillTextActive]}>{f.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <Text style={s.sectionLabel}>STRENGTH · {Math.round(strength * 100)}%</Text>
        <View style={s.sliderTrack}>
          {[0.25, 0.5, 0.75, 1.0].map(v => (
            <TouchableOpacity key={v} style={[s.sliderStep, strength >= v && s.sliderStepActive]} onPress={() => setStrength(v)}>
              <Text style={[s.sliderStepText, strength >= v && s.sliderStepTextActive]}>{Math.round(v * 100)}%</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={[s.captureBtn, isCapturing && s.captureBtnDisabled]} onPress={handleCapture} disabled={isCapturing}>
          <View style={s.captureInner} />
        </TouchableOpacity>
        <Text style={s.captureHint}>{isCapturing ? 'Processing…' : 'Point at artwork and tap to scan'}</Text>
      </ScrollView>
    </View>
  );
}

const GREEN = '#4A7A5E';
const GREEN_LIGHT = '#C4D8C9';
const INK = '#1A1510';
const PARCHMENT = '#F5F0E8';
const MUTED = '#6B6057';
const BORDER = '#D9D1C0';

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: INK },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: PARCHMENT, padding: 32, gap: 16 },
  header: { paddingTop: 56, paddingBottom: 12, paddingHorizontal: 20, backgroundColor: INK },
  headerTitle: { fontSize: 13, letterSpacing: 5, color: GREEN_LIGHT, fontWeight: '300' },
  headerSub: { fontSize: 10, color: MUTED, letterSpacing: 2, marginTop: 2 },
  cameraWrap: { height: W * 0.85, margin: 16, borderRadius: 12, overflow: 'hidden' },
  camera: { flex: 1 },
  corners: { ...StyleSheet.absoluteFillObject },
  corner: { position: 'absolute', width: 24, height: 24 },
  cornerTL: { top: 12, left: 12, borderTopWidth: 2, borderLeftWidth: 2, borderColor: 'white' },
  cornerTR: { top: 12, right: 12, borderTopWidth: 2, borderRightWidth: 2, borderColor: 'white' },
  cornerBL: { bottom: 12, left: 12, borderBottomWidth: 2, borderLeftWidth: 2, borderColor: 'white' },
  cornerBR: { bottom: 12, right: 12, borderBottomWidth: 2, borderRightWidth: 2, borderColor: 'white' },
  activeBadge: { position: 'absolute', bottom: 12, alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(26,21,16,0.7)', paddingVertical: 5, paddingHorizontal: 12, borderRadius: 999 },
  activeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: GREEN_LIGHT },
  activeBadgeText: { fontSize: 11, color: 'white', letterSpacing: 0.5 },
  controls: { flex: 1, backgroundColor: PARCHMENT, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
  controlsInner: { padding: 20, gap: 12, alignItems: 'center' },
  sectionLabel: { alignSelf: 'flex-start', fontSize: 10, letterSpacing: 2, color: MUTED, fontWeight: '500' },
  filterRow: { flexDirection: 'row', gap: 8, alignSelf: 'stretch' },
  filterPill: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 999, borderWidth: 1, borderColor: BORDER, backgroundColor: 'white' },
  filterPillActive: { backgroundColor: GREEN, borderColor: GREEN },
  filterPillText: { fontSize: 12, color: MUTED },
  filterPillTextActive: { color: 'white', fontWeight: '500' },
  sliderTrack: { flexDirection: 'row', gap: 8, alignSelf: 'stretch' },
  sliderStep: { flex: 1, paddingVertical: 8, alignItems: 'center', borderRadius: 8, borderWidth: 1, borderColor: BORDER, backgroundColor: 'white' },
  sliderStepActive: { backgroundColor: GREEN, borderColor: GREEN },
  sliderStepText: { fontSize: 11, color: MUTED },
  sliderStepTextActive: { color: 'white' },
  captureBtn: { width: 72, height: 72, borderRadius: 36, borderWidth: 3, borderColor: GREEN, alignItems: 'center', justifyContent: 'center', marginTop: 8 },
  captureBtnDisabled: { borderColor: BORDER },
  captureInner: { width: 56, height: 56, borderRadius: 28, backgroundColor: GREEN },
  captureHint: { fontSize: 11, color: MUTED, letterSpacing: 0.5 },
  resultImage: { width: W, height: W, backgroundColor: '#000' },
  filterBadge: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 20, paddingTop: 16 },
  filterDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: GREEN_LIGHT },
  filterBadgeText: { fontSize: 13, color: PARCHMENT, letterSpacing: 0.5 },
  filterDesc: { fontSize: 12, color: MUTED, paddingHorizontal: 20, marginTop: 4 },
  resultActions: { flexDirection: 'row', gap: 12, padding: 20, marginTop: 'auto' },
  btn: { flex: 1, paddingVertical: 14, alignItems: 'center', backgroundColor: GREEN, borderRadius: 999 },
  btnOutline: { backgroundColor: 'transparent', borderWidth: 1, borderColor: GREEN_LIGHT },
  btnText: { color: 'white', fontSize: 14, fontWeight: '500' },
  btnTextDark: { color: GREEN_LIGHT },
  permTitle: { fontSize: 22, color: INK, fontWeight: '400', textAlign: 'center' },
  permDesc: { fontSize: 14, color: MUTED, textAlign: 'center', lineHeight: 22 },
});

/**
 * Deuteranopia (red-green) color correction
 * All processing on-device — no internet required
 */

export type FilterStrength = number; // 0.0 to 1.0

/**
 * Daltonization matrix for deuteranopia correction.
 * Redistributes green channel energy to make red/green distinguishable.
 */
export const DEUTERANOPIA_MATRIX = [
  1.0,   0.494, -0.494, 0, 0,
  0.0,   1.0,    0.0,   0, 0,
  0.0,  -0.494,  1.494, 0, 0,
  0,     0,      0,     1, 0,
];

export interface FilterOption {
  id: string;
  label: string;
  description: string;
}

export const FILTERS: FilterOption[] = [
  {
    id: 'none',
    label: 'Original',
    description: 'No filter applied',
  },
  {
    id: 'deuteranopia',
    label: 'Red-Green Fix',
    description: 'Corrects red-green color confusion',
  },
  {
    id: 'enhance',
    label: 'Enhanced',
    description: 'Boosted contrast + red-green fix',
  },
];

/**
 * Apply daltonization to raw pixel data
 * Works entirely on-device with no network calls
 */
export function applyFilter(
  pixelData: Uint8ClampedArray,
  filterId: string,
  strength: number = 1.0
): Uint8ClampedArray {
  if (filterId === 'none') return pixelData;

  const result = new Uint8ClampedArray(pixelData.length);
  const m = DEUTERANOPIA_MATRIX;

  for (let i = 0; i < pixelData.length; i += 4) {
    const r = pixelData[i] / 255;
    const g = pixelData[i + 1] / 255;
    const b = pixelData[i + 2] / 255;

    let rNew = m[0] * r + m[1] * g + m[2] * b;
    let gNew = m[5] * r + m[6] * g + m[7] * b;
    let bNew = m[10] * r + m[11] * g + m[12] * b;

    // Extra contrast boost for 'enhance' mode
    if (filterId === 'enhance') {
      rNew = Math.min(1, rNew * 1.15);
      gNew = Math.min(1, gNew * 1.15);
      bNew = Math.min(1, bNew * 1.15);
    }

    // Blend with original based on strength
    result[i]     = Math.round((r + (rNew - r) * strength) * 255);
    result[i + 1] = Math.round((g + (gNew - g) * strength) * 255);
    result[i + 2] = Math.round((b + (bNew - b) * strength) * 255);
    result[i + 3] = pixelData[i + 3];
  }

  return result;
}
